from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base, User

# engine = create_engine('postgresql://myuser:mypassword@localhost/mydatabase')
engine = create_engine('postgresql://postgres:admin@192.168.1.100/RAD')
Base.metadata.create_all(engine)
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

def create_user(full_name, alias, email, password):
  new_user = User(full_name=full_name, alias=alias, email=email, password=password)
  session.add(new_user)
  session.commit()
  return new_user

def read_users():
  return session.query(User).all()

def update_user(user_id, full_name=None, alias=None, email=None, password=None):
  user = session.query(User).filter_by(id=user_id).first()
  if user:
    if full_name:
      user.full_name = full_name
    if alias:
      user.alias = alias
    if email:
      user.email = email
    if password:
      user.password = password
    session.commit()
    return True
  return False

def delete_user(user_id):
  user = session.query(User).filter_by(id=user_id).first()
  if user:
    session.delete(user)
    session.commit()
    return True
  return False

