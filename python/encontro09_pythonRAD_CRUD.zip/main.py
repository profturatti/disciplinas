import sys
from crud import create_user, read_users, update_user, delete_user

def print_menu():
  print("1. Create User")
  print("2. Read Users")
  print("3. Update User")
  print("4. Delete User")
  print("5. Exit")

def main():
  while True:
    print_menu()
    choice = input("Enter your choice: ")

    if choice == '1':
      full_name = input("Enter full name: ")
      alias = input("Enter alias: ")
      email = input("Enter email: ")
      password = input("Enter password: ")
      create_user(full_name, alias, email, password)
      print("User created successfully!")
    elif choice == '2':
      users = read_users()
      for user in users:
        print(f"ID: {user.id}, Full Name: {user.full_name}, Alias: {user.alias}, Email: {user.email}")
    elif choice == '3':
      user_id = input("Enter user ID to update: ")
      full_name = input("Enter new full name (leave blank to keep unchanged): ")
      alias = input("Enter new alias (leave blank to keep unchanged): ")
      email = input("Enter new email (leave blank to keep unchanged): ")
      password = input("Enter new password (leave blank to keep unchanged): ")
      if update_user(user_id, full_name, alias, email, password):
        print("User updated successfully!")
      else:
        print("User not found!")
    elif choice == '4':
      user_id = input("Enter user ID to delete: ")
      if delete_user(user_id):
        print("User deleted successfully!")
      else:
        print("User not found!")
    elif choice == '5':
      print("Exiting...")
      sys.exit(0)
    else:
      print("Invalid choice. Please try again.")

if __name__ == "__main__":
  main()
