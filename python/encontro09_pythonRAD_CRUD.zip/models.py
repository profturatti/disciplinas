from sqlalchemy import Column, Integer, String, create_engine
# from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import declarative_base, sessionmaker

# 1: Cria a classe base
Base = declarative_base()

# 2: Define classes ORM
class User(Base):
  __tablename__ = 'users'
  id = Column(Integer, primary_key=True)
  full_name = Column(String)
  alias = Column(String)
  email = Column(String, unique=True)
  password = Column(String)

# 3: Cria um engine
engine = create_engine('postgresql://postgres:admin@192.168.1.100/RAD')

# 4. Cria as tabelas no BD
Base.metadata.create_all(engine)

# 5: Cria uma sessao
Session = sessionmaker(bind=engine)
session = Session()


