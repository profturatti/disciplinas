PythonRAD CRUD em modo console com PostgreSQL

Para executar o projeto:

1. Execute o docker para preparar seu ambiente
   > docker-compose up -d

2. Instale os pacotes necessários, caso não os tenha
   > pip install sqlalchemy
   > pip install psycopg2

   SE falhar a instalação do psycopg2, é necessário executar antes
   $ python3 --version
   $ sudo apt install python3.<versao>-dev
   $ sudo apt install libpq-dev
   para resolver o problema no linux e a seguir:
   > pip install psycopg2

3. ANTES de executar qualquer arquivo Python, ajuste os arquivos:
   - models.py e 
   - main.py
   com o IP atual do seu ambiente!
   Para saber qual o IP em uso:
   - no windows, abra um CMD: (btnWindows+R) digite CMD e ENTER
   > ipconfig
   ...
   IPv4 Address..... 192.168.1.100
   ...
   - no linux, abra um terminal 
   $ ifconfig | grep "inet 192"
   inet 192.168.1.100  netmask 255.255.255.0  broadcast 192.168.1.255

   Nos arquivo .py localize a linha

   engine = create_engine('postgresql://postgres:admin@192.168.1.100/RAD')
                                                       ^^^^^^^^^^^^^
   e ajuste com o seu IP atual

4. Na primeira vez que for usar o programa
   > python models.py

5. Para executar o programa
   > python main.py

6. Para encerrar o docker ao finalizar o uso do programa
   > docker-compose stop
   > docker-compose down
   > docker ps
   CONTAINER ID   IMAGE     COMMAND   CREATED   STATUS    PORTS     NAMES
   >_

Visualizando desta forma os containeres foram finalizados com sucesso e
nao existe nada de docker em execucao.


