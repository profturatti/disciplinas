from pessoa import Pessoa
p1 = Pessoa('John ', 40)
p1.parar_comer()
p1.comer('Burger')
p1.falar()


